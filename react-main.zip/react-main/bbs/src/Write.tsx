import {Component} from "react";
import {Form, Button, Container, Row, Col} from "react-bootstrap";

class Write extends Component{
    render(){
        return(
            <>
<Container>
    <Row>
        <Col>
        <Form>
    <Form.Group className="mb-3">
<Form.Label>제목</Form.Label>
<Form.Control
type="text" 
name="title"
/>
    </Form.Group>
</Form>
        </Col>
    </Row>
</Container>            
            </>
           
        )
    }
}

export default Write;
